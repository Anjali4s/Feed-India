export enum FoodType {
    VEG = "VEG",
    NON_VEG = "NON_VEG" , 
    ANY ="ANY" 
}