export interface Transaction {
    id:number
    amount:number
    donationDateTime:string,
    transactionStatus:string,
    user:any
}
