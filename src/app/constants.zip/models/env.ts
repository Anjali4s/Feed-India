export const environment = {
    production: false,
    stripe: {
      publicKey: 'pk_test_51P8z5CSDicQAbcUkyIPAw3YsOl404rddECmDwYa7Ko9Wi4CqvgLXpK3klzbxdxjD3bo90uCnZHhYa3IIb2gnrFKt00f8UwAqyn',
    }
  };