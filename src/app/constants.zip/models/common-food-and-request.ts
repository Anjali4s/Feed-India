export interface CommonFoodAndRequest {
}
